package com.example.demo_db.exception;

public class RoleAuthenticationException extends AuthenticationException {
    public RoleAuthenticationException(String msg) {
        super(msg);
    }
}




import {useDispatch, useSelector} from "react-redux";
import {adminLogout, persistor, setToken, setUerInfoList, userLogout} from "../store";
import {useNavigate} from "react-router-dom";

export default async function Logout(){
    const adminLoginFlag=useSelector(state=>state.userInfo.adminLoginFlag);
    const userLoginFlag =useSelector(state=>state.userInfo.userLoginFlag);
    const dispatch = useDispatch();
    const navigate = useNavigate();

    dispatch(setToken(null));

    if(adminLoginFlag){
        dispatch(adminLogout());
    }
    if(userLoginFlag){
        dispatch(userLogout());
    }
    dispatch(setUerInfoList([]));

    await persistor.purge();
    navigate("/");
    return (
        <>
        </>
    );
}
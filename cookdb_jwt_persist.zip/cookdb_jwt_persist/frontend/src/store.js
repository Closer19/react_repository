import {createSlice, configureStore} from "@reduxjs/toolkit";
import storage from "redux-persist/lib/storage";
import {combineReducers} from "redux";
import {persistReducer, persistStore} from "redux-persist";

const userInfoSlice=createSlice({
    name:"userInfo",
    initialState:{
        userInfoList:[],
        adminLoginFlag:false,
        userLoginFlag:false
    },
    reducers:{
        addUserInfo:(state, action)=>{
            state.userInfoList.push(action.payload);
        },
        setUerInfoList:(state, action)=>{
          state.userInfoList=action.payload;
          state.count=action.payload.length;
        },
        clearUserInfo:(state)=>{
            state.userInfoList=[];
        },
        adminLogin: (state) => {
            state.adminLoginFlag = true;
        },
        adminLogout: (state) => {
            state.adminLoginFlag = false;
        },
        userLogin:(state)=>{
            state.userLoginFlag = true;
        },
        userLogout:(state)=>{
            state.userLoginFlag = false;
        },

    }
});


const initState={
    token:null,
}

const tokenSlice = createSlice({
    name:"token",
    initialState:initState,
    reducers:{
        setToken:(state, action)=>{
            state.token= action.payload;
        }
    }
});

const persistConfig ={
    key:"root", //localStorage에 저장할 때 사용할 최상위 키
    storage,
    whitelist:['userInfo', 'token'], //blacklist 옵션도 있으며, 이는 저장하지 않을 slice를 지정
};

const rootReducer = combineReducers({
    userInfo:userInfoSlice.reducer,
    token:tokenSlice.reducer,
}); //여러 reducer를 하나로 합친 reducer를 만든다.

const persistedReducer = persistReducer(persistConfig, rootReducer);
//상태 저장 및 복원 가능한 reducer로 변환
export const store=configureStore({
    reducer: persistedReducer,
}); //persistedReducer를 기반으로 Redux store를 생성

export const persistor = persistStore(store);
//생성된 store를 기반으로 상태 복원(persist) 기능을 수행할 persistor 객체를 생성

export const {userLogin, userLogout, addUserInfo,clearUserInfo, setUerInfoList, adminLogin, adminLogout}=userInfoSlice.actions;
export const {setToken} = tokenSlice.actions;

package com.example.madangdb_project.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController {
}

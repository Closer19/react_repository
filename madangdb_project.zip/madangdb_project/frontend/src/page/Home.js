export default function Home(){
    return(
        <>
            <h1>마당서점입니다.</h1>
        </>
    );
}
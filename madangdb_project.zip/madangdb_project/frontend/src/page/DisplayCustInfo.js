export default function DisplayCustInfo(){
    return(
        <>
        </>
    );
}
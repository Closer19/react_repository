import { useDispatch, useSelector } from "react-redux";
import { removeToDo } from "./todoSlice";

export default function ToDoList(){
    const todos = useSelector((state) => state.todos.items);
    const dispatch = useDispatch();

    return (
        <>
         <ul>
        {todos.map(todo=>(
          <li key={todo.id}>
            {todo.task}
            <button onClick={()=>dispatch(removeToDo(todo.id))}>Delete</button>
          </li>
        ))}
      </ul>
        </>
    );
}
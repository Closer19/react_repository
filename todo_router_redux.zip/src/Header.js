import { useDispatch } from "react-redux";
import { addToDo } from "./todoSlice";
import { useState } from "react";
import { useNavigate } from "react-router-dom";


export default function Header(){
    const dispatch = useDispatch();  
    const navigate = useNavigate(); 
    return (
        <>
        <h1>To-Do List</h1>
        <form onSubmit={(e)=>{
            e.preventDefault();
            const text =e.target.todo.value.trim();
            if(text){
                dispatch(addToDo(text));
                e.target.todo.value="";
                navigate("/todolist");      
              }
        }}>
        <input type="text" name="todo" placeholder="Add a new task"></input>
      <input type="submit" value="Add Todo"></input>
      </form>
        </>
    );
}
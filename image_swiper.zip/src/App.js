import logo from './logo.svg';
import './App.css';
// import {Swiper} from "swiper";
import {Autoplay, Navigation, Pagination} from "swiper/modules";
import {SwiperSlide, Swiper} from "swiper/react";

import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';

function App() {
    const imageList= [
        { id: 1, src:'/media/africa.jpg', title: "아프리카" },
        { id: 2, src:'/media/brazil.jpg', title: "브라질" },
        { id: 3, src:'/media/canada.jpg', title: "카나다" },
        { id: 4, src:'/media/cuba.jpg', title: "쿠바" }
    ];

  return (
   <>
       <Swiper style={{ width: '50%', height: '400px' }}
           modules ={[Autoplay, Pagination, Navigation]}
           spaceBetween = {30}
           slidesPerView = {1}
           loop = {true}
           autoplay = {{
                   delay: 3000,
               disableOnInteraction : false,
               }}
           pagination = {{clickable:true}}
           navigation = {true}
       >
       <SwiperSlide key={1} style={{
           display: 'flex',
           justifyContent: 'center', // 가로 가운데
           alignItems: 'center'      // 세로 가운데
       }}>
           <img src={"/media/africa1.jpg"}  style={{
               width: '300px',
               height: '200px'}}/>
       </SwiperSlide>
       <SwiperSlide key={2} style={{
           display: 'flex',
           justifyContent: 'center', // 가로 가운데
           alignItems: 'center'      // 세로 가운데
       }}>
         <img src={"/media/africa2.jpg"} style={{
             width: '300px',
             height: '200px'}}/>
       </SwiperSlide>
       <SwiperSlide key={3} style={{
           display: 'flex',
           justifyContent: 'center', // 가로 가운데
           alignItems: 'center'      // 세로 가운데
       }}>
           <img src={"/media/africa3.jpg"} style={{
               width: '300px',
               height: '200px'}}/>
       </SwiperSlide>
       </Swiper>
   </>
  );
}

export default App;

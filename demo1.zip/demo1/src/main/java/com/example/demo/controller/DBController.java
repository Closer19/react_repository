package com.example.demo.controller;

import com.example.demo.data.User;
import com.example.demo.data.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequiredArgsConstructor
public class DBController {
    private final UserRepository userRepository;
//    public DBController(UserRepository userRepository) {
//        this.userRepository = userRepository;
//    }

    @GetMapping(value = "/userlist")
    public List<User> getUserList() {
        List<User> userlist = this.userRepository.findAll();
        return userlist;
    }

    @GetMapping(value = "/userlist/{id}")
    public User getUser(@PathVariable String id) {
        Optional<User> user = this.userRepository.findById(id);
        if (user.isPresent()) {
            return user.get();
        }
        return null;
    }

    @PostMapping(value = "/user")
    public User createUser(@RequestBody User user) {
        return this.userRepository.save(user);
    }

    @DeleteMapping(value = "/user/{var}")
    public String deleteUser(@PathVariable String var) {
        if(this.userRepository.existsById(var)) {
            this.userRepository.deleteById(var);
            return "Delete Success";
        }
        return "Delete Fail";
    }

}

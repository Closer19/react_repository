import { configureStore } from "@reduxjs/toolkit";
import imageListSlice from "./imageListSlice";

const store = configureStore({
    reducer:{
        imageList : imageListSlice.reducer,
    }
});

export default store;
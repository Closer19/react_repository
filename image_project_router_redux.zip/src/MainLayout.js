import Header from './Header';
import ImageSection from './ImageSection';
import { Outlet } from 'react-router-dom';

export default function MainLayout(){      
    
      const title = "국가 갤러리";
      
      return (
        <div className="App">
          <Header title={title}></Header>
          <ImageSection></ImageSection>
          <Outlet/>
        </div>
      );
    
}
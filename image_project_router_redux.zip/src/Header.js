import { Link  } from "react-router-dom";

export default function Header(props){
    const headerStyle={
        textAlign : "center",
    }
   
    return (
        <h1 style={headerStyle}><Link to="/">{props.title}</Link></h1>
    );
}


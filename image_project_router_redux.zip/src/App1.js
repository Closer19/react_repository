
// 이미지가 있는 폴더가 src안에 있을때
// import africaImage from './media/africa.jpg';
// import africaImage1 from './media/africa1.jpg';
// import africaImage2 from './media/africa2.jpg';
// import africaImage3 from './media/africa3.jpg';

export default function App(){
    // 이미지가 있는 폴더가 src안에 있을때
// const imageList = [
//     { id: 1, src: africaImage, desc: "국기" },
//     { id: 2, src: africaImage1, desc: "타조" },
//     { id: 3, src: africaImage2, desc: "나무" },
//     { id: 4, src: africaImage3, desc: "사막" }
//   ];

//   const imgLst=imageList.map((img)=><img src={img.src} width="100" height="100" id={img.id}></img>);

   // 이미지가 있는 폴더가 public안에 있을때
   const imageList= [
    { id: 1, src:'/media/africa.jpg', title: "아프리카" },
    { id: 2, src:'/media/brazil.jpg', title: "브라질" },
    { id: 3, src:'/media/canada.jpg', title: "카나다" },
    { id: 4, src:'/media/cuba.jpg', title: "쿠바" }
  ];

  const imgLst=imageList.map((img)=><img src={img.src} width="100" height="100" id={img.id}></img>);

  
    return (
        <>
        {imgLst}        
        </>
    );
}
import { useSelector } from "react-redux";
import "./imageSection.css";
import { useNavigate } from "react-router-dom";

export default function ImageSection(){
    const navigator = useNavigate();
    const imageList=useSelector((state)=>state.imageList.imgLst);
   
    const list = imageList.map((img)=><img key={img.id} className="img" src={img.src} onClick={event=>{           
        navigator("/imglist/"+ img.id);
    }} ></img>);
    
    return (
        <div className="imageSection">
        {list}
        </div>                
    );
}
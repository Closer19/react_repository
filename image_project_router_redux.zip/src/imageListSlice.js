import { createSlice } from "@reduxjs/toolkit";

const imageListSlice = createSlice({
  name: "imageList",
  initialState: {
    imgLst: [
      { id: 1, src: "/media/africa.jpg", title: "아프리카"},
      { id: 2, src: "/media/brazil.jpg", title: "브라질" ,},
      { id: 3, src: "/media/canada.jpg", title: "카나다" },
      { id: 4, src: "/media/cuba.jpg", title: "쿠바" },
    ],
    nextId : 5,    
  },
  reducers:{
    addImageList:(state, action)=>{
        state.imgLst.push({...action.payload, id:state.nextId});
        state.nextId++;
    },
    deleteImageList:(state, action)=>{
        state.imgLst = state.imgLst.filter((img)=>img.id !== action.payload.id);
    }
  }
});

export const { addImageList, deleteImageList} = imageListSlice.actions;
export default imageListSlice;
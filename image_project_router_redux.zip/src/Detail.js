import { useParams } from "react-router-dom";
import "./imageSection.css";
import { useSelector } from "react-redux";

export default function Detail(){
    const {imgId} = useParams();
    const country = useSelector(state=>state.imageList.imgLst.find((img)=>img.id === Number(imgId)));
    const titleStyle={
        textAlign : "center",
    }
    const imgeList=[];
    for(let i=0; i<3; i++){
        const srcSpilt = country.src.split('.'); // ["/media/brazil", "jpg"]
        const src = srcSpilt[0] + (i+1) + '.' + srcSpilt[1];
        // srcSpilt[0]=srcSpilt[0]+(i+1);
        // const src = srcSpilt.join(".");    
        const imgItem=<img src={src} className="img"></img>
        imgeList.push(imgItem);
    }
    return (
        <>
        <h2 style={titleStyle}>{country.title}</h2>  
        <div className="imageSection">
        {imgeList}
        </div>      

        </>
    );
}
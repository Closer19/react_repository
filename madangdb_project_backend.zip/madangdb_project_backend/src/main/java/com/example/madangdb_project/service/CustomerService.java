package com.example.madangdb_project.service;

import org.springframework.stereotype.Service;

@Service
public class CustomerService {
}

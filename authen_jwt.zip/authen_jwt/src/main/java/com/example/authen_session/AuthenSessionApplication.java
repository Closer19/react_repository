package com.example.authen_session;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthenSessionApplication {

    public static void main(String[] args) {
        SpringApplication.run(AuthenSessionApplication.class, args);
    }

}

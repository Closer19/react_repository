package com.example.authen_session;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthenSessionApplicationTests {

    @Test
    void contextLoads() {
    }

}

String serverIp="http://3.39.100.13";

class Oauth2Url{
  static final googleRedirectUrl="${serverIp}/api/login/oauth2/code/google";
  static final naverRedirectUrl="${serverIp}/api/login/oauth2/code/naver";
  static final googleAuthenUrl= "${serverIp}/api/google";
  static final naverAuthenUrl= "${serverIp}/api/naver";
}



import 'package:flutter/material.dart';
import 'package:login/url/oauth2_url.dart';
import 'package:provider/provider.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import './token_info.dart';
import './dice.dart';

class SocialAuthScreen extends StatefulWidget {
  late final oauth2Url;
  late final oauth2RedirectUrl;

  SocialAuthScreen({required this.oauth2Url, required this.oauth2RedirectUrl});

  @override
  _SocialAuthScreenState createState() => _SocialAuthScreenState();
}

class _SocialAuthScreenState extends State<SocialAuthScreen> {
  late final WebViewController _controller;
  String? loginMessge=null;


  @override
  void initState() {
    super.initState();

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
          onPageStarted: (String url) {
        // 페이지 로딩 시작
      }, onPageFinished: (String url) {
        // 페이지 로딩 완료
      }, onNavigationRequest: (NavigationRequest request) async { //onNavigationRequest : 웹 페이지가 새로운 URL로 이동하려고 할 때
        TokenInfo provider = context.read<TokenInfo>();
        if (request.url.startsWith(widget.oauth2RedirectUrl)) {
          Uri url = Uri.parse(request.url);
          final headers = {"andriodApp" : "AndroidApp"};
          final response = await http.get(url, headers: headers);
          Map<String, dynamic> token = json.decode(utf8.decode(response.bodyBytes));
          provider.accessToken = token["access_token"];
          provider.refreshToken = token["refresh_token"];
          if (provider.accessToken != null && provider.refreshToken!=null ) {
            Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => Dice(),
                ));
            return NavigationDecision.prevent;
          }
        }
        return NavigationDecision.navigate;
        }
      ))
      ..loadRequest(Uri.parse(widget.oauth2Url));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Social Authentication'),
      ),
      body: WebViewWidget(
        controller: _controller, // WebViewController 연결
      ),
    );
  }
}

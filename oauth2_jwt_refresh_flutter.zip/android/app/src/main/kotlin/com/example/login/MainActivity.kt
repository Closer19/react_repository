package com.example.login_jwt_oauth2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()


import { Outlet } from "react-router-dom";
import Nevigate from "./Navigate";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import {productAdd} from "./productSlice";

export default function MainLayout(){
    const dispatch = useDispatch();
    useEffect(()=>{

        const fetchData = async ()=>{
            try{
                const response = await fetch("http://localhost:8080/product-list");
                if(!response.ok){
                    throw new Error("네트워크 에러");
                }
                const data = await response.json();
                data.map(p=>dispatch(productAdd(p)));
            }catch(error){
                console.log(error);
            }
        }
        fetchData();
    }, []);
    
    return (
        <>
        <h1>TEST STORE</h1>
        <Nevigate></Nevigate>
        <Outlet></Outlet>
        </>
    );
}
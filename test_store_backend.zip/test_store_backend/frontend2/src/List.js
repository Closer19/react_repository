import {useDispatch, useSelector} from "react-redux";
import {productDelete, productUpdate} from "./productSlice";
import { Link } from "react-router-dom";
export default function List(){
    const pdList = useSelector(state=>state.product.productList);
    const dispatch = useDispatch();

    const handleDelete = async (e)=>{
        try{
            const response = await fetch("http://localhost:8080/product/"+e.target.id, {
                method:"DELETE",
            });
            if(!response.ok){
                throw new Error("네트워크 오류");
            }
            const data = await response.text();
            dispatch(productDelete(e.target.id));
            console.log(data);

        }catch(error){
            console.log(error);
        }
        
    };

    const list = pdList.map(t=>(
        <div key={t.id}>
            <br/>
            <Link to={"/detail-product/"+t.id}><img src={t.imagesrc}/></Link>
            <h3>{t.title}</h3>
            <Link to={"/edit-product/"+t.id}> 🖋 </Link>
            <span id={t.id} onClick={handleDelete}>🗑</span>
            <br/><br/>
        </div>
    ));
    
    return (
        <>
            {list}
        </>
    );
}
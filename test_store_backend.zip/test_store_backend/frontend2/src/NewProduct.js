import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { productAdd } from "./productSlice";
import { useRef} from "react";

export default function NewProduct(){
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const handleSubmit = async e=>{
        e.preventDefault();
        const p = {title:e.target.title.value, price:Number(e.target.price.value)};
        try{
            const response = await fetch("http://localhost:8080/new-product", {
                method:"POST",
                headers:{
                    "Content-Type":"application/json"
                },
                body : JSON.stringify(p),
            });
            if(!response.ok){
                throw new Error("네트워크 오류");
            }
            const data = await response.json();
            dispatch(productAdd(data));
        }catch(error){
            console.log(error);
        }
       
        navigate("/");
    }

    return (
        <>
        <h2>New Product</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" name="title"></input>
                <input type="text" name="price"></input>
                <button type="submit">저장</button>
            </form>

        </>
    );
}
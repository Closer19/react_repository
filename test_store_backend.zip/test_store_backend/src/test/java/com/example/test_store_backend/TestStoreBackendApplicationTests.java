package com.example.test_store_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestStoreBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}

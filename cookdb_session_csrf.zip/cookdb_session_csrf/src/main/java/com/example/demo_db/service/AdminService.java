package com.example.demo_db.service;

import com.example.demo_db.data.dao.AdminDAO;
import com.example.demo_db.data.dto.AdminDTO;
import com.example.demo_db.data.entity.AdminEntity;
import com.example.demo_db.exception.AuthenticationException;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AdminService {
    private final AdminDAO adminDAO;
    private final PasswordEncoder passwordEncoder;

    public AdminDTO saveAdmin(AdminDTO adminDTO) {
        if(!adminDTO.getAuthenNumber().equals("1234")){
            throw new AuthenticationException("관리자 인증번호가 틀립니다.");
        }
        if(this.adminDAO.existAdmin(adminDTO.getAuthenNumber())){
            throw new DuplicateKeyException("이미 있는 관리자 아이디입니다.");
        }

        AdminEntity adminEntity = AdminEntity.builder()
                .username(adminDTO.getUsername())
                .password(this.passwordEncoder.encode(adminDTO.getPassword()))
                .build();
        AdminEntity saveAdminEntity=this.adminDAO.saveAdmin(adminEntity);

        AdminDTO saveAdminDTO=AdminDTO.builder()
                .username(saveAdminEntity.getUsername())
                .password(saveAdminEntity.getPassword())
                .build();
        return saveAdminDTO;
    }

}

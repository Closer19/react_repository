import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      home: MyPage(),
    );
  }
}

class MyPage extends StatelessWidget {
  const MyPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        foregroundColor: Colors.white,
        title: Text("Appbar icon menu"),
        centerTitle: true,
        actions: [
          IconButton(
              onPressed: (){
                print("장바구니 클릭!!");
              },
              icon: Icon(Icons.shopping_cart)
          ),
          IconButton(
              onPressed: (){
                print("검색 클릭!!");
              },
              icon: Icon(Icons.search)
          ),
        ],
      ),
      drawer:
    );
  }
}

class AccountDetailsDrawer extends StatefulWidget {
  const AccountDetailsDrawer({super.key});

  @override
  State<AccountDetailsDrawer> createState() => _AccountDetailsDrawerState();
}

class _AccountDetailsDrawerState extends State<AccountDetailsDrawer> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          UserAccountsDrawerHeader(
            decoration: BoxDecoration(
                color: Colors.red[200],
                borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(40),
                    bottomLeft: Radius.circular(40)
                )
            ),
            accountName: Text("kja0204"),
            accountEmail: Text("prettkja@gmail.com"),
            currentAccountPicture: CircleAvatar(
              backgroundImage: AssetImage("assets/sun-15710_256.gif"),
              radius: 40,
              backgroundColor: Colors.red[200],
            ),
            onDetailsPressed: (){

            },
          ),
          ListTile(
            leading: Icon(Icons.home,
              color: Colors.grey[850],),
            title: Text("Home"),
            trailing: Icon(Icons.add),
            onTap: (){
              print("Home 클릭!!");
            },
          ),
          ListTile(
            leading: Icon(Icons.question_answer,
              color: Colors.grey[850],),
            title: Text("Q&A"),
            trailing: Icon(Icons.add),
            onTap: (){
              print("Q&A 클릭!!");
            },
          ),
          ListTile(
            leading: Icon(Icons.settings,
              color: Colors.grey[850],),
            title: Text("Settings"),
            trailing: Icon(Icons.add),
            onTap: (){
              print("Settings 클릭!!");
            },
          ),

        ],
      ),
    );
  }
}

